package com.sudhakar.service;

import com.sudhakar.entity.User;

public interface UserService {
	void registerUser(User user);
    User loginUser(String email, String password);
    void forgotPassword(String email);

}
