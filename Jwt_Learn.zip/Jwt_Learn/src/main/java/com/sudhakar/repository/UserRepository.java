package com.sudhakar.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sudhakar.entity.User;



public interface UserRepository extends JpaRepository<User, Long> {
    User findByEmail(String email);
}
